// const mongoose = require('mongoose');
// const Planet = mongoose.model('Planet');

// ----------------------------- REQUIRE -----------------------------
const request = require('request');

// ----------------------------- apiOptions -----------------------------
// const apiOptions = {
//   server : 'https://localhost:443'
// };
// if (process.env.NODE_ENV === 'production') {
//   apiOptions.server = '';
// }

const apiOptions = {
  server: process.env.API_SERVER || 'http://localhost:8000'
};

if (process.env.NODE_ENV === 'production') {
  apiOptions.server = ''; // same-origin (тот же домен, что и сайт)
}


// Build API base per request; default to same-origin unless API_SERVER set
// const apiOptions = (req) => process.env.API_SERVER || `${req.protocol}://${req.get('host')}`;

// ----------------------------- homelist -----------------------------
const homelist = function(req, res) {
  const path = '/api/planets';
  const requestOptions = {
    url: apiOptions.server + path,
    method: 'GET',
    json: {}
  };

  request(requestOptions, (err, response, body) => {
    if (err) {
      console.log("API ERROR:", err);
      return res.render('error', { message: 'API error', error: err });
    } else if (response.statusCode !== 200) {
      return res.render('error', {
        message: `Unexpected status: ${response.statusCode}`,
        error: body
      });
    }

    _renderPlanetList(req, res, body);
  });
};

const _renderPlanetList = function(req, res, apiData) {
  res.render('planets', {
    title: "Planets",
    planets: apiData
  });
};

// ----------------------------- planetDetail -----------------------------
const planetDetail = function(req, res) {
  const path = `/api/planets/${req.params.id}`;
  const requestOptions = {
    url: apiOptions.server + path,
    method: 'GET',
    json: {}
  };

  request(requestOptions, (err, response, body) => {
    if (err) {
      console.log("API ERROR:", err);
      return res.render('error', { message: 'API error', error: err });
    } else if (response.statusCode !== 200) {
      return res.render('error', {
        message: `Unexpected status: ${response.statusCode}`,
        error: body
      });
    }

    _renderPlanetDetail(req, res, body);
  });
};


const _renderPlanetDetail = function(req, res, planetData) {
  res.render('planet_detail', {
    title: planetData.name,
    planet: planetData
  });
};

// ----------------------------- EXPORTS -----------------------------
module.exports = {
  homelist,
  planetDetail
};