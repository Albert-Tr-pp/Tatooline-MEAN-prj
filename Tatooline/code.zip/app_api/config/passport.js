// const passport = require('passport');
// const LocalStrategy = require('passport-local').Strategy;
// const User = require('../models/users');

// // Explicitly use email as the username field
// passport.use(new LocalStrategy({ usernameField: 'email' }, User.authenticate()));
// passport.serializeUser(User.serializeUser());
// passport.deserializeUser(User.deserializeUser());

// module.exports = passport;


// ----------------------------- TEST -----------------------------
// const passport = require('passport');
// const User = require('../models/users');

// passport.use(User.createStrategy());
// passport.serializeUser(User.serializeUser());
// passport.deserializeUser(User.deserializeUser());

// module.exports = passport;
